package Ex2;

public class Circle extends Shape{
	int r;
	public Circle(int r) {
		this.r = r;
	}
	@Override
	public double getEdgeSize() {
		return Math.PI * r * 2;
	}

	@Override
	public double getAreaSize() {
		return Math.PI * r * r;
	}
}

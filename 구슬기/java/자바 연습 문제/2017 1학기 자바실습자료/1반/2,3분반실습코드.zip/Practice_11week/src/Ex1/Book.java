package Ex1;

interface Book {
	void printWriter();
	void printTitle();
	void printContent();
}
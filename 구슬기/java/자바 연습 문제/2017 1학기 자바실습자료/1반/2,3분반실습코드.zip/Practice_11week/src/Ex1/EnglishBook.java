package Ex1;

class EnglishBook implements Book {
	@Override
	public void printWriter() {
		System.out.println("���� : Byun Woon-Jo");
	}

	@Override
	public void printTitle() {
		System.out.println("���� : English Textbook");
	}

	@Override
	public void printContent() {
		System.out.println("å ����");
		System.out.println("Java is a programming language and computing platform ");
		System.out.println("first released by Sun Microsystems in 1995.");
	}
}
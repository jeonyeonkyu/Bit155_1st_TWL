package Ex3;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Stack stack = new Stack();

		while (true) {
			System.out.println("�޴�\r\n1. Push, 2. Pop, 3. ����");
			int menuNum = sc.nextInt();

			if (menuNum == 1) {
				System.out.println("�����Է� ");
				int inputNum = sc.nextInt();
				stack.push(inputNum);
				stack.printCurrentStack();
			} else if (menuNum == 2) {
				stack.pop();
				stack.printCurrentStack();
			} else {
				break;
			}
		}
	}
}

package Ex3;

public class Stack extends StackManager{
	
	int[] stack = new int[1000];
	int index = -1;
	
	@Override
	void push(int value) {
		stack[++index] = value;
	}

	@Override
	void pop() {
		index--;
	}

	@Override
	void printCurrentStack() {
		System.out.println("���� ���� ũ��� "+(index+1)+"�Դϴ�..");
			System.out.println("-------------");
		for (int i = index; i >= 0; i--) {
			System.out.println(stack[i]);
		}
		System.out.println("-------------");
	}

}

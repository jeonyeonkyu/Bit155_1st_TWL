package Ex2;

public class Rectangle extends Shape{
	int w, h;
	public Rectangle(int w, int h) {
		this.w = w;
		this.h = h;
	}
	@Override
	public double getEdgeSize() {
		return 2 * (w + h);
	}

	@Override
	public double getAreaSize() {
		return w * h;
	}
}

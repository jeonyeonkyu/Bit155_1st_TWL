package ex3;

public class User {
	String name ="";
	int age = 0 ;
	
	public User(String name, int age) {
		this.name = name;
		this.age = age;
	}
	
	public User(int age, String name) {
		this.name = name;
		this.age = age;
	}
	
	public User(String name) {
		this.name = name;
	}
	
	public User(int age) {
		this.age = age;
	}
	
	public void set(String name){
		this.name = name;
	}
	
	public void set(int age){
		this.age = age;
	}
	
}

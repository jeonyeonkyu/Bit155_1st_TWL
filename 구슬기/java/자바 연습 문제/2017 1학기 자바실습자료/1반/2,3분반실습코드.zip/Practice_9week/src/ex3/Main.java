package ex3;

import java.util.Scanner;

public class Main{

	public static void main(String[] args) {
		User user1 = new User("�ڸ���", 16);
		User user2 = new User(44, "���缮");
		User user3 = new User("������");
		User user4 = new User(82);
		Scanner sc = new Scanner(System.in);

		// ��ü �迭�� ����ص� �������
		while (true) {
			System.out.println("������ȣ\t�̸�\t����");
			System.out.println("======================");
			System.out.println("1\t" + user1.name + "\t" + user1.age);
			System.out.println("2\t" + user2.name + "\t" + user2.age);
			System.out.println("3\t" + user3.name + "\t" + user3.age);
			System.out.println("4\t" + user4.name + "\t" + user4.age);
			System.out.println("������ ���� ��ȣ �Է� (���� : 0)");
			int userNum = sc.nextInt();
			if (userNum == 0) {
				System.out.println("������ȣ\t�̸�\t����");
				System.out.println("======================");
				System.out.println("1\t" + user1.name + "\t" + user1.age);
				System.out.println("2\t" + user2.name + "\t" + user2.age);
				System.out.println("3\t" + user3.name + "\t" + user3.age);
				System.out.println("4\t" + user4.name + "\t" + user4.age);
				break;
			} else if (userNum == 1) {
				System.out.println("�̸� :");
				String name = sc.next();
				System.out.println("���� :");
				int age = sc.nextInt();
				user1.set(age);
				user1.set(name);
			} else if (userNum == 2) {
				System.out.println("�̸� :");
				String name = sc.next();
				System.out.println("���� :");
				int age = sc.nextInt();
				user2.set(age);
				user2.set(name);
			} else if (userNum == 3) {
				System.out.println("�̸� :");
				String name = sc.next();
				System.out.println("���� :");
				int age = sc.nextInt();
				user3.set(age);
				user3.set(name);
			} else {
				System.out.println("�̸� :");
				String name = sc.next();
				System.out.println("���� :");
				int age = sc.nextInt();
				user4.set(age);
				user4.set(name);
			}
		}
	}
}

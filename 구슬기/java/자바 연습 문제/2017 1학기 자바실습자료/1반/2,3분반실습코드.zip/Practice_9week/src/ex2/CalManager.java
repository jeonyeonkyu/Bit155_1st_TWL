package ex2;

public class CalManager {
	public CalManager() {

	}

	public void calValue(int val1, String val2, String operator) {   // ù��° �ǿ����ڰ� int �ι�° �ǿ����ڰ� string
		int value1 = val1;
		int value2 = Integer.parseInt(val2);
		System.out.println("value1 : int, value : String");
		System.out.println("(value1 : "+value1+") "+operator+ " (value2 : "+value2+" )");
		if (operator.equals("+")) {
			System.out.println(value1+value2);
		} else if (operator.equals("-")) {
			System.out.println(value1-value2);
		} else if (operator.equals("*")) {
			System.out.println(value1*value2);
		} else {
			System.out.println(value1/value2);
		}
	}

	public void calValue(String val1, int val2, String operator) {
		int value1 = Integer.parseInt(val1);
		int value2 = val2;
		System.out.println("value1 : String, value : int");
		System.out.println("(value1 : "+value1+") "+operator+ " (value2 : "+value2+" )");
		if (operator.equals("+")) {
			System.out.println(value1+value2);
		} else if (operator.equals("-")) {
			System.out.println(value1-value2);
		} else if (operator.equals("*")) {
			System.out.println(value1*value2);
		} else {
			System.out.println(value1/value2);
		}
	}

	public void calValue(int val1, int val2, String operator) {
		int value1 = val1;
		int value2 = val2;
		System.out.println("value1 : int, value : int");
		System.out.println("(value1 : "+value1+") "+operator+ " (value2 : "+value2+" )");
		if (operator.equals("+")) {
			System.out.println(value1+value2);
		} else if (operator.equals("-")) {
			System.out.println(value1-value2);
		} else if (operator.equals("*")) {
			System.out.println(value1*value2);
		} else {
			System.out.println(value1/value2);
		}
	}

	public void calValue(String val1, String val2, String operator) {
		int value1 = Integer.parseInt(val1);
		int value2 = Integer.parseInt(val2);
		System.out.println("value1 : String, value : String");
		System.out.println("(value1 : "+value1+") "+operator+ " (value2 : "+value2+" )");
		if (operator.equals("+")) {
			System.out.println(value1+value2);
		} else if (operator.equals("-")) {
			System.out.println(value1-value2);
		} else if (operator.equals("*")) {
			System.out.println(value1*value2);
		} else {
			System.out.println(value1/value2);
		}
	}

}

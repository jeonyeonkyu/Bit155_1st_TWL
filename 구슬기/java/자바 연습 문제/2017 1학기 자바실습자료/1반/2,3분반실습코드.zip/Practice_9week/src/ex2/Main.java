package ex2;

import java.util.Random;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Random ran = new Random();
		CalManager cm = new CalManager();
		
		while (true) {
			System.out.println("���� �Դϴ�\r\n�Է¹�� : 3+3\r\n�Է¹ٶ�!!");
			String temp = sc.nextLine();
			String tempArr[] = temp.split(" ");
			int value1 = ran.nextInt(2) + 1;  // 1 �Ǵ� 2���� ����
			int value2 = ran.nextInt(2) + 1; // 1�̸� int , 2�̸� string
			
			if (value1 == 1 && value2 == 2) { // int , string
				cm.calValue(Integer.parseInt(tempArr[0]), tempArr[2], tempArr[1]);
			} else if (value1 == 2 && value2 == 1) { // String , int
				cm.calValue(tempArr[0], Integer.parseInt(tempArr[2]), tempArr[1]);
			} else if (value1 == 1 && value2 == 1) { // int , int
				cm.calValue(Integer.parseInt(tempArr[0]),Integer.parseInt(tempArr[2]), tempArr[1]);
			} else { // string , string
				cm.calValue(tempArr[0], tempArr[2], tempArr[1]);
			}
		}
	}
}

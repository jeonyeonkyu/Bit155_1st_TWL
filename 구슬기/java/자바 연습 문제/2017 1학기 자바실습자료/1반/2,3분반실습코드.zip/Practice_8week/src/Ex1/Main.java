package Ex1;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Plus plus = new Plus();
		Minus minus = new Minus();
		Multiplication multiplication = new Multiplication();
		Division division = new Division();
		Scanner sc = new Scanner(System.in);
		String str;
		int num1;
		int num2;
		String[] strArr = new String[3];
		
		System.out.println("==����==");
		while (true) {
			System.out.println("����� ���� �Է�(Ex 3 + 3) : ");
			str = sc.nextLine();
			System.out.println(str);
			strArr = str.split(" ");
			num1 = Integer.parseInt(strArr[0]);
			num2 = Integer.parseInt(strArr[2]);
			if (strArr[1].equals("+")) {
				plus.setValue(num1, num2);
				plus.calculate();
			}else if (strArr[1].equals("-")) {
				minus.setValue(num1, num2);
				minus.calculate();
			}else if (strArr[1].equals("*")) {
				multiplication.setValue(num1, num2);
				multiplication.calculate();
			}else if (strArr[1].equals("/")) {
				division.setValue(num1, num2);
				division.calculate();
			}else{
				System.out.println("���� �� �߸� �Է�");
				break;
			}
		}
	}
}

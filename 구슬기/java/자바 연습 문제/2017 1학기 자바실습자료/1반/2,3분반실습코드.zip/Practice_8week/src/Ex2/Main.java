package Ex2;

import java.util.Random;

public class Main {
	public static void main(String[] args) {
		HighLowGame highLowGame = new HighLowGame();
		
		highLowGame.startGame();
		highLowGame.setComNumber();
		highLowGame.compareUsertoCom();
		highLowGame.endGame();
	}
}

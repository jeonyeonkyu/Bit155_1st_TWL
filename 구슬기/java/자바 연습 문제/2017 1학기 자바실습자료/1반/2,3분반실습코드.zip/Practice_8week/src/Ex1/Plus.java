package Ex1;

public class Plus {
	int num1;
	int num2;

	public void setValue(int num1, int num2) {
		this.num1 = num1;
		this.num2 = num2;
	}

	public void calculate() {
		System.out.println(num1 + num2);
	}
}

package Ex2;

public class Pasta extends Food{
	int kcal;
	int price;
	int kg;
	
	public Pasta(int kcal, int price, int kg) {
		super(kcal, price, kg);
		this.kcal = kcal;
		this.price = price;
		this.kg = kg;
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String PrintInfo() {
		// TODO Auto-generated method stub
		return super.PrintInfo();
	}
}

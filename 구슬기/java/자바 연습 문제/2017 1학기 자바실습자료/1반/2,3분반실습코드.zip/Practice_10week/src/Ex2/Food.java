package Ex2;

public class Food {
	private int kcal;
	private int price;
	private int kg;

	public Food(int kcal, int price, int kg) {
		this.kcal = kcal;
		this.price = price;
		this.kg = kg;
	}

	public String PrintInfo() {
		String info = "Food [kcal=" + kcal + ", price=" + price + ", kg=" + kg + "]";
		return info;
	}

}
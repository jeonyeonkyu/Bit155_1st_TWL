package Ex3;

import java.util.Random;

public class Main {
	public static void main(String[] args) {
		Random ran = new Random();
		int intArr[] = new int[10];
		EvenNumber evenNumber = new EvenNumber();
		
		
		for (int i = 0; i < intArr.length; i++) {
			intArr[i] = ran.nextInt(100)+1;
			evenNumber.process(intArr[i]);
		}
	}
}

package Ex3;

public class EvenNumber extends OddNumber{
	
	OddNumber oddNumber = new OddNumber();
	
	
	public void process(int num){
		if (num%2 == 0) {  // ¦
			printInfo(num);
		}else if (num%2 != 0) {  // Ȧ
			super.printInfo(num);
		}
	}
	
	public void printInfo(int num){
		System.out.println(num+" : ¦�� �Դϴ�...");
	}
}

package Ex3;

public class OddNumber {
	
	public void printInfo(int num){
		System.out.println(num+" : Ȧ�� �Դϴ�...");
	}
}

package Ex1;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		System.out.println("*** ���� ���� ***");
		Scanner sc = new Scanner(System.in);
		DecimalManager dm = new DecimalManager();
		String[] inputArray;
		
		while (true) {
			System.out.print(">>");
			inputArray = sc.nextLine().split(" ");
			if (inputArray[0].equals("exit")) {
				System.out.println("���α׷��� ���� �մϴ�");
				System.out.println("*** ���� ���� ***");
				break;
			}else{
				dm.checkDecimal(inputArray[0], inputArray[1], inputArray[2]);
			}
		}
	}
}

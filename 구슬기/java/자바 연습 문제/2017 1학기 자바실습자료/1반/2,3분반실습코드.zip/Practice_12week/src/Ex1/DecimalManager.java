package Ex1;

public class DecimalManager {
	int num1;
	int num2;
	String sum;
	
	void checkDecimal(String index, String numStr1, String numStr2){
		System.out.print("������� >>  ");
		if (index.equals("bin")) {   // 2����
			num1 = Integer.parseInt(numStr1, 2);
			num2 = Integer.parseInt(numStr2, 2);
			sum = Integer.toBinaryString(num1+num2);
			System.out.println(sum);
		}else if (index.equals("oct")) {  // 8����
			num1 = Integer.parseInt(numStr1, 8);
			num2 = Integer.parseInt(numStr2, 8);
			sum = Integer.toOctalString(num1+num2);
			System.out.println(sum);
		}else if (index.equals("dec")) {  // 10����
			num1 = Integer.parseInt(numStr1);
			num2 = Integer.parseInt(numStr2);
			sum = Integer.toString(num1+num2);
			System.out.println(sum);
		}else{  // 16����
			num1 = Integer.parseInt(numStr1, 16);
			num2 = Integer.parseInt(numStr2, 16);
			sum = Integer.toHexString(num1+num2);
			System.out.println(sum);
		}
	}
}

package Ex3;

public class StackManager {
	int[] stack;
	int index;

	public StackManager() {
		stack = new int[1000];
		index = -1;
	}

	public void push(int value) {
		stack[++index] = value;
	}

	public void pop() {
		index--;
	}
	
	public void printStack(){
		for (int i = index; i >= 0; i--) {
			System.out.println(stack[i]);
		}
	}
}

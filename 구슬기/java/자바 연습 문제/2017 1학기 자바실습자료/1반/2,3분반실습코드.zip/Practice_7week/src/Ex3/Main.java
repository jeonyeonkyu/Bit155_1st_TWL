package Ex3;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		StackManager sm = new StackManager();
		
		while(true){
			System.out.println("�޴�\r\n1. push, 2. pop, 3. ����");
			int key = sc.nextInt();
			
			if (key == 1) {
				System.out.println("���� �Է�");
				int num = sc.nextInt();
				sm.push(num);
			}else if (key == 2) {
				System.out.println("���� �Է�");
				int num = sc.nextInt();
			}else{
				System.out.println("�����մϴ�...");
			}
		}
	}
}

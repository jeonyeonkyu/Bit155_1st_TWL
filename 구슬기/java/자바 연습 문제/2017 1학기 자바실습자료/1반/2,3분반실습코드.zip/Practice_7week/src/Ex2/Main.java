package Ex2;

import java.util.Random;

public class Main {
	public static void main(String[] args) {
		Conversion conversion = new Conversion();
		Random ran = new Random();
		int num = ran.nextInt(100)+1;
		System.out.println("���� �߻� : "+num);
		
		conversion.multiplyThree(num);
		conversion.includeThree(num);
	}
}

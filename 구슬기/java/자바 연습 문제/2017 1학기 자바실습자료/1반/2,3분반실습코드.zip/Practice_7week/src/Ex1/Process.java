package Ex1;

public class Process {
	public Process() {
		System.out.println("==����==");
	}

	public int plus(int num1 , int num2) {
		int result= num1 + num2;
		return  result;
	}
	
	public int minus(int num1 , int num2) {
		int result=num1 - num2;
		return  result;
	}
	
	public int multiply(int num1 , int num2) {
		int result=num1 * num2;
		return  result;
	}
	
	public float division(int num1 , int num2) {
		float result= num1/num2;
		return  result;
	}

}

package Ex2;

public class Conversion {

	public void multiplyThree(int num) {
		System.out.print("3�� ��� : ");
		for (int i = 1; i <= num; i++) {
			if (i%3 == 0) {
				System.out.print(i+" ");
			}
		}
		System.out.println();
	}

	public void includeThree(int num) {
		System.out.print("3�� �����ϴ� �� : ");
		for (int i = 1; i <= num; i++) {
			if (i%10 == 3 || i/10 == 3) {
				System.out.print(i+" ");
			}
		}
	}
}

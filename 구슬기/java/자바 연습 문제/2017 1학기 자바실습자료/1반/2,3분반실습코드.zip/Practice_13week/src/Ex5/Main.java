package Ex5;

public class Main {
	
	public static void main(String[] args) {
		Conversion cs = new Conversion();
		System.out.println(cs.intToString("1"));
		System.out.println(cs.intToString("2"));
		System.out.println(cs.intToString("11"));
		System.out.println(cs.intToString("22"));
		System.out.println(cs.intToString("111"));
		System.out.println(cs.intToString("222"));
	}
}

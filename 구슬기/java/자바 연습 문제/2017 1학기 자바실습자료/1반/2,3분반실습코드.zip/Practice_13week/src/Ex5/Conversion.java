package Ex5;

public class Conversion {
	public String intToString(String inputStr) {
		String[] arrStr1 = { "", "��", "��", "��", "��", "��", "��", "ĥ", "��", "��" };
		String[] arrStr2 = { "", "", "��", "��", "��", "��", "��", "ĥ", "��", "��" };
		String[] arrStr3 = { "", "��", "��"};
		StringBuffer result = new StringBuffer();
		int len = inputStr.length();
		for (int i = len - 1; i >= 0; i--) {
			if (len>1 && i!=0) {
				result.append(arrStr2[Integer.parseInt(inputStr.substring(len - i - 1, len - i))]);
				if (Integer.parseInt(inputStr.substring(len - i - 1, len - i)) > 0)
					result.append(arrStr3[i % 4]);
			}else{
				result.append(arrStr1[Integer.parseInt(inputStr.substring(len - i - 1, len - i))]);
				if (Integer.parseInt(inputStr.substring(len - i - 1, len - i)) > 0)
					result.append(arrStr3[i % 4]);
			}
		}
		return result.toString();
	}
}

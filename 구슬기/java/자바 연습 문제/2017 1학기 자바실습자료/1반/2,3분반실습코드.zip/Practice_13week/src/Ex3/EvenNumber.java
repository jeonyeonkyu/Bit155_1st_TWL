package Ex3;

public class EvenNumber extends OddNumber{
	String sentence;
	OddNumber oddNumber = new OddNumber();
	FileManager fm = new FileManager();
	
	public void process(int num){
		if (num%2 == 0) {  // ¦
			fm.setResult(printInfo(num));
		}else if (num%2 != 0) {  // Ȧ
			fm.setResult(super.printInfo(num));
		}
	}
	
	public String printInfo(int num){
		sentence = num+" : ¦�� �Դϴ�...\r\n";
		System.out.print(sentence);
		return sentence;
	}
}

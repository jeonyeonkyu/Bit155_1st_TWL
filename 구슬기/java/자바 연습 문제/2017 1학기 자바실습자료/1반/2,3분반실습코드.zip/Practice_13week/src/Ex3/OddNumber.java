package Ex3;

public class OddNumber {
	String sentence;

	public String printInfo(int num) {
		sentence = num + " : Ȧ�� �Դϴ�...\r\n";
		System.out.print(sentence);
		return sentence;
	}
}

package Ex3;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Random;

public class FileManager {
	FileInputStream fis1;
	FileInputStream fis2;
	FileOutputStream fos1;
	FileOutputStream fos2;
	Random ran;
	String reverseStr;
	int oddNum;
	int evenNum;

	public FileManager() {
		try {
			fos1 = new FileOutputStream("C:\\Users\\Kwon\\Desktop\\result.txt");
			fos2 = new FileOutputStream("C:\\Users\\Kwon\\Desktop\\reverseResult.txt");
			fis1 = new FileInputStream("C:\\Users\\Kwon\\Desktop\\result.txt");
			ran = new Random();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void setResult(String sentence) {                // result.txt�� ����
		try {
			fos1.write(sentence.getBytes());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String getResult() {    // result.txt���� ���ڸ� �о�� �� ����
		byte[] buffer = new byte[1024];
		try {
			fos1.close();
			fis1.read(buffer);
			reverseStr = new String(buffer);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return reverseStr;
	}
	
	public void setReverseResult(){
		try {
			String[] str1 = getResult().split("\r\n"); // ���پ� �ڸ���
			String[] str2; // ���� �ڸ� ���忡�� ���ø��� �迭
			String str = "";
			for (int i = 0; i < str1.length-1; i++) {
				str2 = str1[i].split(" ");
				if (str2[2].equals("¦��")) {
					str2[0] = String.valueOf(ran.nextInt(50)*2);
				}else{
					str2[0] = String.valueOf(ran.nextInt(50)*2+1);
				}
				str = str + str2[0]+" "+str2[1]+" "+str2[2]+" "+str2[3]+"\r\n";
			}
			fos2.write(str.getBytes());
			fos2.close();
			System.out.println(str);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

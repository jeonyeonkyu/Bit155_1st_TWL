package Ex2;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		try {
			FileWriter fw = new FileWriter("C:\\Users\\Kwon\\Desktop\\text.txt");
			FileReader fr = new FileReader("C:\\Users\\Kwon\\Desktop\\text.txt");
			Scanner sc = new Scanner(System.in);
			Scanner sc2 = new Scanner(System.in);
			int i;
			System.out.println("=======���� ������=======");
			while (true) {
				System.out.println("��带 �����Ͻÿ�(1 = �Է¸�� / 2 = ��¸�� / 3 = ����)");
				int mode = sc.nextInt();
				if (mode == 1) {
					System.out.println("���ڸ� �Է��Ͻÿ� !");
					String sentence = sc2.nextLine() + "\r\n";
					fw.write(sentence);
					fw.flush();
				} else if (mode == 2) {
					System.out.println("���ڸ� ����մϴ� !");
					while ((i = fr.read()) != -1) {
						System.out.print((char)i);
					}
				} else {
					break;
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
package Ex1;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		try {
		User user1 = new User("�ڸ���", 16);
		User user2 = new User(44, "���缮");
		User user3 = new User("������");
		User user4 = new User(82);
		Scanner sc = new Scanner(System.in);
		FileWriter fw = new FileWriter("C:\\Users\\Kwon\\Desktop\\user.txt");

		while (true) {
			System.out.println("������ȣ\t�̸�\t����");
			System.out.println("======================");
			System.out.println("1\t" + user1.name + "\t" + user1.age);
			System.out.println("2\t" + user2.name + "\t" + user2.age);
			System.out.println("3\t" + user3.name + "\t" + user3.age);
			System.out.println("4\t" + user4.name + "\t" + user4.age);
			System.out.println("������ ���� ��ȣ �Է� (���� : 0)");
			int userNum = sc.nextInt();
			if (userNum == 0) {
				System.out.println("������ȣ\t�̸�\t����");
				fw.write("������ȣ\t�̸�\t����\r\n");
				System.out.println("======================");
				fw.write("======================\r\n");
				System.out.println("1\t" + user1.name + "\t" + user1.age);
				fw.write("1\t" + user1.name + "\t" + user1.age+"\r\n");
				System.out.println("2\t" + user2.name + "\t" + user2.age);
				fw.write("2\t" + user2.name + "\t" + user2.age+"\r\n");
				System.out.println("3\t" + user3.name + "\t" + user3.age);
				fw.write("3\t" + user3.name + "\t" + user3.age+"\r\n");
				System.out.println("4\t" + user4.name + "\t" + user4.age);
				fw.write("4\t" + user4.name + "\t" + user4.age+"\r\n");
				fw.close();
				break;
			} else if (userNum == 1) {
				System.out.println("�̸� :");
				String name = sc.next();
				System.out.println("���� :");
				int age = sc.nextInt();
				user1.set(age);
				user1.set(name);
			} else if (userNum == 2) {
				System.out.println("�̸� :");
				String name = sc.next();
				System.out.println("���� :");
				int age = sc.nextInt();
				user2.set(age);
				user2.set(name);
			} else if (userNum == 3) {
				System.out.println("�̸� :");
				String name = sc.next();
				System.out.println("���� :");
				int age = sc.nextInt();
				user3.set(age);
				user3.set(name);
			} else {
				System.out.println("�̸� :");
				String name = sc.next();
				System.out.println("���� :");
				int age = sc.nextInt();
				user4.set(age);
				user4.set(name);
			}
		}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

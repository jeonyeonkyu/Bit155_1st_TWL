package week10_3;

public class Main {

	public static void main(String[] args) {
		
//		Scanner sc = new Scanner(System.in);
		
		new ScrambleGame().start();
		
	}

}

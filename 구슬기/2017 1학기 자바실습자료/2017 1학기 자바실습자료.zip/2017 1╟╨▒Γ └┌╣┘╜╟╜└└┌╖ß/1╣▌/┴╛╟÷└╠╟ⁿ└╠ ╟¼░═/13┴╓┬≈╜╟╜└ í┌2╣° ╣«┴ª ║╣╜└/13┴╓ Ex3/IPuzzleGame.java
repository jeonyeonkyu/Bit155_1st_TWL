public interface IPuzzleGame {

	void info();
	void setAnswer();
	void start();
	void process();
	void check();
	void end();
}
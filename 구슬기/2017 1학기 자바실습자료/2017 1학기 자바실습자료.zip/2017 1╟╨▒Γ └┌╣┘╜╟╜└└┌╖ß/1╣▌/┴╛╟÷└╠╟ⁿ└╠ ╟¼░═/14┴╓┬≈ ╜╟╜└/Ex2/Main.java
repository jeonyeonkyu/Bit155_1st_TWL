
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		StudentList java01 = new StudentList("�ڹ� �ǽ� 01��", "2017/06/12",4);
		java01.writeList();
		java01.readList();
		}
	
	}



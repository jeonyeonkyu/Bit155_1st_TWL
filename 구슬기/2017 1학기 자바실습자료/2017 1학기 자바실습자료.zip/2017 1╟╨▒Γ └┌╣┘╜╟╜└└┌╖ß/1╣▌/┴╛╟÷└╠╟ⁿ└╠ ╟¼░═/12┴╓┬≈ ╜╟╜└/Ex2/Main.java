
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		StudentList java01 = new StudentList("�ڹ� �ǽ� 01��", "2017/05/22",4);
		java01.writeList();
		java01.readList();
		}
	
	}



	public interface IList{
		
		void Info();
		void writeList();
		void readList();

	}




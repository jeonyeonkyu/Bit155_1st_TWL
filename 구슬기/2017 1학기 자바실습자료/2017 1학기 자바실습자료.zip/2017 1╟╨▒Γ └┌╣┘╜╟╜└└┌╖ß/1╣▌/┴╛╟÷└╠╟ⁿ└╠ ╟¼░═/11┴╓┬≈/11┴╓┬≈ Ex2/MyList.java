import java.util.Scanner;
public class MyList {


	
	Scanner sc = new Scanner(System.in);
	String strTitle;
	String strDate;
	String[] strNames;
	int iCount;
	
	public void MyList(String mTitle, int mCount, String mDate)	{
		
	}
	
	public void writeList()	{
		
		System.out.println("=== ���� �Է� ===");
		
	}
		
	public void readList()	{
		
		System.out.println("=== �Էµ� ���� ===");
			
	}
	
	public void listInfo(){
		
	}

}


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		StudentList java01 = new StudentList("�ڹ� �ǽ� 01��", 4, "2017/05/22");
		java01.writeList();
		java01.readList();
		}
	
	}



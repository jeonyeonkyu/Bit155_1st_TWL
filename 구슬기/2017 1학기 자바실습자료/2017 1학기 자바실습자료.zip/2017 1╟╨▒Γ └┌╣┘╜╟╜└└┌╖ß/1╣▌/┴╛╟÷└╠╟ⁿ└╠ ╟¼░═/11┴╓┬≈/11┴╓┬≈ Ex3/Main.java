
public class Main03 {
	public static void main(String[] args){
		new ScrambleGame().start();
	}
}


public class Ex2 {
	public static void main (String[] args){
		Cafe myCafe = new Cafe("Holly");
		myCafe.cafeInfo();
		myCafe.showMenu();
		myCafe.makeCoffee();
		myCafe.makeCoffee(true);
		myCafe.makeLatter("����");
		myCafe.makeLatter("����",true);
		
		
	}
}

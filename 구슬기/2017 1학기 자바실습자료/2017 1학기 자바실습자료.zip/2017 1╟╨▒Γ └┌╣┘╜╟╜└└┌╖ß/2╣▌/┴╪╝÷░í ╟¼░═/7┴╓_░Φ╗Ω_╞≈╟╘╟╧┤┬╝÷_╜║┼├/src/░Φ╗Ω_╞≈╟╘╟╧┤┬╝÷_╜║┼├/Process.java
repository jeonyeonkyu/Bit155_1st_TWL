package ���_�����ϴ¼�_����;

public class Process {
	int result;
	public int plus(int a, int b){
		result= a+b;
		return result;
	}
	public int minus(int a,int b){
		result= a-b;
		return result;
	}
	public int multiply(int a,int b){
		result= a*b;
		return result;
	}
	public double division(int a,int b){
		double result1= a/b;
		return result1;
	}
}

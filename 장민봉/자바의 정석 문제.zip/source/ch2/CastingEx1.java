class CastingEx1 {
	public static void main(String[] args) {
		double d  = 85.4;
		int score = (int)d;

		System.out.println("score="+score);
		System.out.println("d="+d);
	}
}

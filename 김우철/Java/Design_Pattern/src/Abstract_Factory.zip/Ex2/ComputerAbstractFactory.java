package Abstract_Factory.Ex2;

public interface ComputerAbstractFactory {
	public Computer createComputer();
}

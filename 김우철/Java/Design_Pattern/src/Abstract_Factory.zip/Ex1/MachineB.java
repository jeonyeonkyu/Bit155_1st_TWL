package Abstract_Factory.Ex1;

public interface MachineB {
	public void process();

}

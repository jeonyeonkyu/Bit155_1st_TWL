package Abstract_Factory.Ex1;

public class MachineB2 implements MachineB{

	@Override
	public void process() {
		System.out.println("execute MachineB2");
		
	}

}

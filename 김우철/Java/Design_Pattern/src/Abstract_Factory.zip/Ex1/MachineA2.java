package Abstract_Factory.Ex1;

public class MachineA2 implements MachineA{

	@Override
	public void process() {
		System.out.println("execute MachineA2");
	}
	
}

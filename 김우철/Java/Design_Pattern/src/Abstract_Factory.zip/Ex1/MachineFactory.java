package Abstract_Factory.Ex1;

public interface MachineFactory {
	public MachineA getMachineA();
	public MachineB getMachineB();

}

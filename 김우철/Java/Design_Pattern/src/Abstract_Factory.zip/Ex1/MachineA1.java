package Abstract_Factory.Ex1;

public class MachineA1 implements MachineA{

	@Override
	public void process() {
		System.out.println("execute MachineA1");
	}
	
}

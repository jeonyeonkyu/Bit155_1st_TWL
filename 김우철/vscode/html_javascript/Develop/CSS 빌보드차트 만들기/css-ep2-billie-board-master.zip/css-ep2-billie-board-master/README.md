# BillieBoard | Episode 2 | DevelUP Live Session

## 구름IDE Container
- https://goor.me/r91aK

## Git Repository
https://github.com/develup-official/css-ep2-billie-board

## 강의 전체내용 Youtube URL
https://youtu.be/f_0nm22OYtA

## 필요한 기초개념
- 선택자 Seletor
- 가상요소 Pseudo Elements 
- 마진겹침 Margin Collapse 
- 포지션속성 Position Property

## 더미데이터
```
Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor.

Truth Hurts
Risso

Senorita
Shawn Mendes & Camila Cabello

Someone You Loved
Lewis Capaldi

Ran$om
Lil Tecca

No Guidance
Chris Brown Featuring Drake

Bad Guy
Billie Eilish
```

## 금일 라이브세션에 대한 설문조사
[설문조사 참여하기](https://docs.google.com/forms/d/e/1FAIpQLSeEIZihnkWejqqtA2sXG56Neinr-F9yGt0-HAobfbBFSY65DA/viewform)

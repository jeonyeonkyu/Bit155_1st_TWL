# 12단 그리드를 만들기 위한 기초지식
- Box Model
- %unit
- box-sizing property
- Negative Margins
- float
- clearfix


# 12단 그리드 예제
https://d.pr/Gkz9ji


# 참고사이트
- https://caniuse.com
- https://960.gs
- https://develup.goorm.io
- https://veamcamp.com


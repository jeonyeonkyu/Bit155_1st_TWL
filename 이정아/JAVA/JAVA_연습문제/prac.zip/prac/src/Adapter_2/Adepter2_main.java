package Adapter_2;

public class Adepter2_main {

	public static void main(String[] args) {
		Ticket_A a = new TicketSystem_A();
		a.menuChoice("���");
		a.cash_buy(2);
		a.print();
		System.out.println("=======================");
		Ticket_G g = new TicketSystem_G();
		g.menuChoice("�����");
		g.card_Buy("����");
		g.print();
		System.out.println(g.get_sales_volume());
	}

}

package Adapter_2;

public interface Ticket_G {
	public void menuChoice(String choice);

	public void card_Buy(String type);

	public void cash_Buy(int coin);

	public void print();

	public String get_sales_volume();
}

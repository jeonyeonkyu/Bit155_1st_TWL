package Adapter_2;

public class Intergration_TicketSystem_ByAdapter implements Ticket_G {
	Ticket_A ticket;
	
	public Intergration_TicketSystem_ByAdapter(Ticket_A ticket) {
		this.ticket = ticket;
	}

	@Override
	public void menuChoice(String choice) {
		ticket.menuChoice(choice);
		
	}

	@Override
	public void card_Buy(String type) {
		throw new UnsupportedOperationException("�������� �ʴ� ����Դϴ�.");
	}

	@Override
	public void cash_Buy(int coin) {
		ticket.cash_buy(coin);
		
	}

	@Override
	public void print() {
		ticket.print();
		
	}

	@Override
	public String get_sales_volume() {
		throw new UnsupportedOperationException("�������� �ʴ� ����Դϴ�.");
	
	}
	
}

package Proxy;

public class RealImage implements imageListView {
	private String imageName;

	public RealImage(String imageName) {
		this.imageName = imageName;
	}

	@Override
	public void draw() {
		System.out.println("�̹��� �ε�..." + imageName);

	}

	public void diskImage() {
		System.out.println("�̹��� ĳ��" + imageName);
	}
}

package Proxy;

public interface imageListView {
	public void draw();
}

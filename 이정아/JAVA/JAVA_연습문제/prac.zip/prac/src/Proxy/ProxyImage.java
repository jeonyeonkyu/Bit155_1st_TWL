package Proxy;

public class ProxyImage implements imageListView {
	private RealImage image;
	private String imageName;

	public ProxyImage(String imageName) {
		this.imageName = imageName;
	}

	@Override
	public void draw() {
		if (image == null) { // �̹����� ������ �ε��ϱ�
			image = new RealImage(imageName);
			image.draw();
		} else {
			image.diskImage();
		}

	}

}

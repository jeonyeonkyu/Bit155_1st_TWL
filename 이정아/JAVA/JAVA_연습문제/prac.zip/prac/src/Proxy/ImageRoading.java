package Proxy;

public class ImageRoading {

	public static void main(String[] args) {
		imageListView image = new ProxyImage("file");
		imageListView image1 = new ProxyImage("file1");

		image.draw();
		image.draw();
		image.draw();

		image1.draw();
		image1.draw();
		image1.draw();
		image1.draw();
	}

}

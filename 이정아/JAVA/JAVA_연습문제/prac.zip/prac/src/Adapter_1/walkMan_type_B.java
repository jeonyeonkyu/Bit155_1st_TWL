package Adapter_1;

public class walkMan_type_B implements walkMan {
	@Override
	public void playtape(String tapename) {
		System.out.println("playing tape" + tapename);
	}

	@Override
	public void stop() {
		System.out.println("���� ����");
		
	}
}

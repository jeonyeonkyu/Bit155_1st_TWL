package Adapter_1;

public interface walkMan {
	void playtape(String tapename);
	void stop();
}
package Adapter_1;

public interface iriver {
	void play(String filename);
	void stop();
	void record();
	void recordStop();
}

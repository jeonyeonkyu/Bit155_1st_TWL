package Adapter_1;

public class walkMan_type_A implements walkMan {

	@Override
	public void playtape(String tapename) {
		System.out.println(tapename);

	}

	@Override
	public void stop() {
	System.out.println("���� ����");
		
	}

}
package prac_java;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class Calculator {
	int result1;
	public void operator() {
		Scanner sc = new Scanner(System.in);
		String[] opr = { "+", "-", "/", "*" };
		String input;
		int num = 0;
		int num2 = 0;
		int oper = 0;
		System.out.println("������ �Է��ϼ���. :  (ex 1+1)");
		input = sc.nextLine();
		String[] save = new String[input.length()];
		for(int i = 0; i < save.length; i++) {
			save[i] = (input.substring(i,i+1));
			for(int j = 0; j < opr.length; j++) {
				if(save[i].equals(opr[j])) {
					 oper= i;
					num = Integer.parseInt(input.substring(0));
					num2 = Integer.parseInt(input.substring(2));
					
			}
		}
	
	switch(opr[oper]) {
	case "+":
		plus(num, num2);
		break;
	case "-":
		minus(num, num2);
		break;
	case "*":
		multiply(num, num2);
		break;
	case "/":
		division(num, num2);
		break;
}
		}
	}

	public void plus(int iNum1, int iNum2) {
		result1 = iNum1 + iNum2;
		System.out.println(iNum1 + "+" + iNum2 + "=" + result1);
	}

	public void minus(int iNum1, int iNum2) {
		result1 = iNum1 - iNum2;
		System.out.println(iNum2 + "-" + iNum2 + "=" + result1);
	}

	public void multiply(int iNum1, int iNum2) {
		result1 = iNum1 * iNum2;
		System.out.println(iNum2 + "*" + iNum2 + "=" + result1);
	}

	public void division(int iNum1, int iNum2) {

		if (iNum2 == 0) {
			System.out.println("0���δ� ���� �� �����ϴ�.");
		} else {
			this.result1 = iNum1 / iNum2;
			System.out.println(iNum2 + "/" + iNum2 + "=" + result1);
		}

	}

	public static void main(String[] args) {
		Calculator cal = new Calculator();
		cal.operator();

	}
}

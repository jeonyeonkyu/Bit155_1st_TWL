function excall(){
    alert('external');
}